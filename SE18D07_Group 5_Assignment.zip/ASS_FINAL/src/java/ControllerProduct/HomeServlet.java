package ControllerProduct;

import Models.Brand;
import Models.Category;
import Models.Product;
import Models.User;
import ProductDao.ProductDao;
import ProductDao.BrandDao;
import ProductDao.CategoryDao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "HomeServlet", urlPatterns = {"/home"})
public class HomeServlet extends HttpServlet {

    private ProductDao productDao;

    @Override
    public void init() {
        productDao = new ProductDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");

            // Chỉ admin mới xem được sản phẩm unavailable
            boolean isAdmin = currentUser != null && 
                 (currentUser.getRole().getRoleName().equalsIgnoreCase("admin") || 
                  currentUser.getRole().getRoleName().equalsIgnoreCase("manager"));


            // Lấy danh sách brand và category
            BrandDao brandDao = new BrandDao();
            CategoryDao categoryDao = new CategoryDao();
            List<Brand> brands = brandDao.selectAllBrands();
            List<Category> categories = categoryDao.selectAllCategories();

            request.setAttribute("brands", brands);
            request.setAttribute("categories", categories);

            // Lọc sản phẩm
            String keyword = request.getParameter("keyword");
            String[] selectedBrands = request.getParameterValues("brand");
            String[] selectedCategories = request.getParameterValues("category");

            int page = 1;
            int pageSize = 12;
            String pageParam = request.getParameter("page");
            if (pageParam != null) {
                page = Integer.parseInt(pageParam);
            }

            List<Product> products;
            int totalProducts;

            if ((selectedBrands != null && selectedBrands.length > 0)
                    || (selectedCategories != null && selectedCategories.length > 0)) {
                // Truyền thêm isAdmin cho tất cả các phương thức lấy sản phẩm
                totalProducts = productDao.getTotalFilteredProducts(selectedBrands, selectedCategories, isAdmin);
                products = productDao.getFilteredProducts(selectedBrands, selectedCategories, page, pageSize, isAdmin);
            } else if (keyword != null && !keyword.trim().isEmpty()) {
                totalProducts = productDao.getTotalSearchProducts(keyword, isAdmin);
                products = productDao.searchProducts(keyword, page, pageSize, isAdmin);
            } else {
                totalProducts = productDao.getTotalProducts(isAdmin);
                products = productDao.getProductsByPage(page, pageSize, isAdmin);
            }

            int totalPages = (int) Math.ceil((double) totalProducts / pageSize);

            request.setAttribute("products", products);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("keyword", keyword);
            request.setAttribute("selectedBrands", selectedBrands);
            request.setAttribute("selectedCategories", selectedCategories);

        } catch (Exception e) {
            e.printStackTrace();
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);
    }

}
