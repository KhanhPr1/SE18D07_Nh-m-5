package ControllerProduct;

import Models.Brand;
import java.sql.SQLException;
import ProductDao.BrandDao;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

@WebServlet(name = "BrandServlet", urlPatterns = {"/brands"})
public class BrandServlet extends HttpServlet {

    private BrandDao brandDao;

    @Override
    public void init() {
        brandDao = new BrandDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "list":
                    listBrands(request, response);
                    break;
                case "create":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteBrand(request, response);
                    break;
                default:
                    listBrands(request, response);
                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "create":
                    insertBrand(request, response);
                    break;
                case "edit":
                    updateBrand(request, response);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/brands?action=list");
                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void listBrands(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<Brand> brands = brandDao.selectAllBrands();
        request.setAttribute("brands", brands);
        RequestDispatcher dispatcher = request.getRequestDispatcher("brand/BrandList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("brand/CreateBrand.jsp");
        dispatcher.forward(request, response);
    }

    private void insertBrand(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String brandName = request.getParameter("brandName");
        String description = request.getParameter("description");
        Brand newBrand = new Brand(brandName);
        newBrand.setDescription(description);
        brandDao.insertBrand(newBrand);
        response.sendRedirect(request.getContextPath() + "/brands?action=list");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Brand existingBrand = brandDao.selectBrand(id);
        request.setAttribute("brand", existingBrand);
        RequestDispatcher dispatcher = request.getRequestDispatcher("brand/EditBrand.jsp");
        dispatcher.forward(request, response);
    }

    private void updateBrand(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String brandName = request.getParameter("brandName");
        String description = request.getParameter("description");
        Brand brand = new Brand(id, brandName);
        brand.setDescription(description);
        brandDao.updateBrand(brand);
        response.sendRedirect(request.getContextPath() + "/brands?action=list");
    }

    private void deleteBrand(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        brandDao.deleteBrand(id);
        response.sendRedirect(request.getContextPath() + "/brands?action=list");
    }
}
