
package ControllerUser;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/displayLoginCount")
public class LoginCountServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ServletContext context = request.getServletContext();

        // Lấy số liệu từ ServletContext
        Integer loggedInUsers = (Integer) context.getAttribute("loggedInUsers");
        Integer loggedInManagers = (Integer) context.getAttribute("loggedInManagers");
        Integer totalLoggedIn = (Integer) context.getAttribute("totalLoggedIn");

        // Nếu chưa có giá trị, khởi tạo về 0
        if (loggedInUsers == null) {
            loggedInUsers = 0;
        }
        if (loggedInManagers == null) {
            loggedInManagers = 0;
        }
        if (totalLoggedIn == null) {
            totalLoggedIn = 0;
        }

        // Đưa số liệu lên request attributes
        request.setAttribute("loggedInUsers", loggedInUsers);
        request.setAttribute("loggedInManagers", loggedInManagers);
        request.setAttribute("totalLoggedIn", totalLoggedIn);

        // Forward sang JSP hiển thị
        request.getRequestDispatcher("Listener/loginCount.jsp").forward(request, response);
    }
}