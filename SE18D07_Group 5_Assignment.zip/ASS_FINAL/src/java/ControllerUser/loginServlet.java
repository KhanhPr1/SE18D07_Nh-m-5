package ControllerUser;

import Models.User;
import Models.CartItem;
import ServiceUser.loginService;
import ProductDao.CartDao;
import Utilities.CartCookieUtil;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "loginServlet", urlPatterns = {"/login"})
public class loginServlet extends HttpServlet {

    private loginService loginService = new loginService();
    private CartDao cartDao = new CartDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/authenticator_authorization/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String identifier = request.getParameter("identifier");
        String password = request.getParameter("password");
        String remPass = request.getParameter("rem");

        Cookie cu = new Cookie("cuser", identifier);
        Cookie cp = new Cookie("cpass", password);
        Cookie cr = new Cookie("crem", remPass);

        if (remPass != null) {
            cu.setMaxAge(60 * 60 * 24 * 7);
            cp.setMaxAge(60 * 60 * 24 * 7);
            cr.setMaxAge(60 * 60 * 24 * 7);
        } else {
            cu.setMaxAge(0);
            cp.setMaxAge(0);
            cr.setMaxAge(0);
        }

        response.addCookie(cu);
        response.addCookie(cp);
        response.addCookie(cr);

        User user = loginService.authenticate(identifier, password);

        if (user != null) {
            if (user.isLocked()) {
                request.setAttribute("errorMessage", "Tài khoản của bạn đang bị khóa.");
                request.getRequestDispatcher("login").forward(request, response);
                return;
            }

            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            
            // Synchronize cart after login
            synchronizeCart(request, response, user);
            
            // Check if there's a return URL to redirect to
            String returnUrl = (String) session.getAttribute("returnUrl");
            if (returnUrl != null) {
                session.removeAttribute("returnUrl");
                response.sendRedirect(returnUrl);
            } else {
                response.sendRedirect(request.getContextPath() + "/home");
            }
        } else {
            request.setAttribute("errorMessage", "Tên đăng nhập hoặc mật khẩu không đúng.");
            request.getRequestDispatcher("login").forward(request, response);
        }
    }
    
    // Method to synchronize guest cart with user cart after login
    private void synchronizeCart(HttpServletRequest request, HttpServletResponse response, User user) {
        try {
            HttpSession session = request.getSession();
            
            // Get existing cart from session (if any)
            List<CartItem> sessionCart = (List<CartItem>) session.getAttribute("cart");
            
            // Get cart from cookie (if any)
            List<CartItem> cookieCart = CartCookieUtil.getCartFromCookie(request);
            
            // Get cart from database (if any)
            List<CartItem> dbCart = cartDao.getCartItems(user.getUserId());
            
            // Merge all carts (cookie takes precedence over database for the same product)
            List<CartItem> mergedCart = mergeAllCarts(cookieCart, sessionCart, dbCart);
            
            // Save merged cart to session and database
            session.setAttribute("cart", mergedCart);
            cartDao.saveCartToDatabase(user, mergedCart);
            
            // Clear cart cookie since it's now in the database
            CartCookieUtil.clearCartCookie(response);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Method to merge all carts
    private List<CartItem> mergeAllCarts(List<CartItem> cookieCart, List<CartItem> sessionCart, List<CartItem> dbCart) {
        List<CartItem> mergedCart = new ArrayList<>();
        
        // Add all items from database first
        if (dbCart != null) {
            mergedCart.addAll(dbCart);
        }
        
        // Add items from session cart (if not already in merged cart)
        if (sessionCart != null) {
            for (CartItem sessionItem : sessionCart) {
                boolean found = false;
                for (CartItem mergedItem : mergedCart) {
                    if (mergedItem.getProduct().getProductId() == sessionItem.getProduct().getProductId()) {
                        // Update quantity if the session cart has a different quantity
                        mergedItem.setQuantity(sessionItem.getQuantity());
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    mergedCart.add(sessionItem);
                }
            }
        }
        
        // Add items from cookie cart (if not already in merged cart)
        if (cookieCart != null) {
            for (CartItem cookieItem : cookieCart) {
                boolean found = false;
                for (CartItem mergedItem : mergedCart) {
                    if (mergedItem.getProduct().getProductId() == cookieItem.getProduct().getProductId()) {
                        // Update quantity if the cookie cart has a different quantity
                        mergedItem.setQuantity(cookieItem.getQuantity());
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    mergedCart.add(cookieItem);
                }
            }
        }
        
        return mergedCart;
    }
}