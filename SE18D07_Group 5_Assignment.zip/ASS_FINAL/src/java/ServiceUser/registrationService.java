
package ServiceUser;

import Models.Role;
import Models.User;
import UserDao.UserDAO;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class registrationService {
    private UserDAO userDao = new UserDAO();


    public void registerUser(String username, String email, String password,
                             String phoneNumber, String fullName, String sex,
                             String birthDateStr) throws SQLException {
        
        
        Date birthDate = null;
        try {
            
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            
            birthDate = sdf.parse(birthDateStr);
        } catch (ParseException e) {
            e.printStackTrace();
            
            birthDate = new Date();
        }

        Role role = new Role(3, "User");

       
        String avatar = "default.gif";  
        int score = 0;                  
        boolean locked = false;         
        
        
        java.sql.Timestamp currentTime = new java.sql.Timestamp(System.currentTimeMillis());

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setFullName(fullName);
        user.setRole(role);
        user.setPhoneNumber(phoneNumber);
        user.setAvatar(avatar);
        user.setScore(score);
        user.setSex(sex);
        user.setBirthDate(birthDate);
        user.setCreatedAt(currentTime);
        user.setUpdatedAt(currentTime);
        user.setLocked(locked);
        
        userDao.insertUser(user);
    }
}
