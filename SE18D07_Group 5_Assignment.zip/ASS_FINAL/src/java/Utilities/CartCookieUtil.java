package Utilities;

import Models.CartItem;
import Models.Product;
import ProductDao.ProductDao;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.Base64;

public class CartCookieUtil {
    private static final String CART_COOKIE_NAME = "guest_cart";
    private static final int COOKIE_MAX_AGE = 60 * 60 * 24 * 30; // 30 days
    
    // Save cart to cookie
    public static void saveCartToCookie(HttpServletResponse response, List<CartItem> cart) {
        try {
            JSONArray jsonCart = new JSONArray();
            
            for (CartItem item : cart) {
                JSONObject jsonItem = new JSONObject();
                jsonItem.put("productId", item.getProduct().getProductId());
                jsonItem.put("quantity", item.getQuantity());
                jsonCart.add(jsonItem);
            }
            
            String jsonString = jsonCart.toString();
            String encodedCart = Base64.getEncoder().encodeToString(jsonString.getBytes());
            
            Cookie cartCookie = new Cookie(CART_COOKIE_NAME, encodedCart);
            cartCookie.setMaxAge(COOKIE_MAX_AGE);
            cartCookie.setPath("/");
            response.addCookie(cartCookie);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // Get cart from cookie
    public static List<CartItem> getCartFromCookie(HttpServletRequest request) {
        List<CartItem> cart = new ArrayList<>();
        Cookie[] cookies = request.getCookies();
        
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (CART_COOKIE_NAME.equals(cookie.getName())) {
                    try {
                        String encodedCart = cookie.getValue();
                        byte[] decodedBytes = Base64.getDecoder().decode(encodedCart);
                        String jsonString = new String(decodedBytes);
                        
                        JSONParser parser = new JSONParser();
                        JSONArray jsonCart = (JSONArray) parser.parse(jsonString);
                        
                        ProductDao productDao = new ProductDao();
                        
                        for (Object obj : jsonCart) {
                            JSONObject jsonItem = (JSONObject) obj;
                            int productId = ((Long) jsonItem.get("productId")).intValue();
                            int quantity = ((Long) jsonItem.get("quantity")).intValue();
                            
                            Product product = productDao.selectProduct(productId);
                            if (product != null && product.getStock() >= quantity) {
                                cart.add(new CartItem(product, quantity));
                            }
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    break;
                }
            }
        }
        
        return cart;
    }
    
    // Clear cart cookie
    public static void clearCartCookie(HttpServletResponse response) {
        Cookie cartCookie = new Cookie(CART_COOKIE_NAME, "");
        cartCookie.setMaxAge(0);
        cartCookie.setPath("/");
        response.addCookie(cartCookie);
    }
}