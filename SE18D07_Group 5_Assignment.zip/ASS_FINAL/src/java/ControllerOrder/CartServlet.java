package ControllerOrder;

import Models.CartItem;
import Models.Product;
import Models.User;
import ProductDao.ProductDao;
import ProductDao.CartDao;
import Utilities.CartCookieUtil;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "CartServlet", urlPatterns = {"/cart"})
public class CartServlet extends HttpServlet {

    private CartDao cartDao = new CartDao();

    private List<CartItem> getCart(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        List<CartItem> cart;

        // If user is logged in, get cart from session or database
        if (user != null) {
            cart = (List<CartItem>) session.getAttribute("cart");
            // If no cart in session, get from database
            if (cart == null) {
                cart = cartDao.getCartItems(user.getUserId());
                session.setAttribute("cart", cart);
            }
        } else {
            // For guest users, get cart from session or cookie
            cart = (List<CartItem>) session.getAttribute("cart");
            // If no cart in session, try to get from cookie
            if (cart == null) {
                cart = CartCookieUtil.getCartFromCookie(request);
                session.setAttribute("cart", cart);
            }
        }

        // If cart is still null, create a new one
        if (cart == null) {
            cart = new ArrayList<>();
            session.setAttribute("cart", cart);
        }

        return cart;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "view":
                    viewCart(request, response);
                    break;
                case "delete":
                    deleteCartItem(request, response);
                    break;
                default:
                    viewCart(request, response);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            viewCart(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        try {
            switch (action) {
                case "add":
                    addToCart(request, response);
                    break;
                case "update":
                    updateCart(request, response);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/cart?action=view");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/cart?action=view");
        }
    }

    private void addToCart(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException, SQLException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Đoạn code gốc yêu cầu đăng nhập:
        /*
        // If user is not logged in and guest cart is disabled
        if (user == null) {
            // Redirect to login page with a return URL
            String returnUrl = request.getRequestURI() + "?" + request.getQueryString();
            session.setAttribute("returnUrl", returnUrl);
            request.setAttribute("errorMessage", "Please log in to add items to your cart");
            request.getRequestDispatcher("/login").forward(request, response);
            return;
        }
         */
        // Đã bỏ đoạn kiểm tra đăng nhập ở trên để cho phép khách thêm vào giỏ hàng
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        ProductDao productDao = new ProductDao();
        Product product = null;

        try {
            product = productDao.selectProduct(productId);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/error.jsp");
            return;
        }

        if (product == null) {
            response.sendRedirect(request.getContextPath() + "/error.jsp");
            return;
        }

        // Check if product is available
        if (!"Available".equals(product.getStatus()) || product.getStock() < quantity) {
            request.setAttribute("errorMessage", "This product is not available in the requested quantity");
            viewCart(request, response);
            return;
        }

        List<CartItem> cart = getCart(request, response);

        boolean found = false;
        for (CartItem item : cart) {
            if (item.getProduct().getProductId() == productId) {
                item.setQuantity(item.getQuantity() + quantity);
                found = true;
                break;
            }
        }

        if (!found) {
            cart.add(new CartItem(product, quantity));
        }

        // Save cart to appropriate storage
        saveCart(request, response, cart);

        response.sendRedirect(request.getContextPath() + "/cart?action=view");
    }

    private void updateCart(HttpServletRequest request, HttpServletResponse response)
            throws IOException, SQLException {
        List<CartItem> cart = getCart(request, response);

        // Create a copy of the cart to avoid ConcurrentModificationException
        List<CartItem> updatedCart = new ArrayList<>();

        for (CartItem item : cart) {
            int productId = item.getProduct().getProductId();
            int qty = Integer.parseInt(request.getParameter("quantity_" + productId));

            // Only add items with quantity > 0
            if (qty > 0) {
                // Check if requested quantity is available
                if (qty <= item.getProduct().getStock()) {
                    item.setQuantity(qty);
                    updatedCart.add(item);
                } else {
                    // If requested quantity exceeds stock, set to maximum available
                    item.setQuantity(item.getProduct().getStock());
                    updatedCart.add(item);
                    request.setAttribute("errorMessage",
                            "Quantity for " + item.getProduct().getProductName()
                            + " adjusted to maximum available: " + item.getProduct().getStock());
                }
            }
        }

        // Replace cart with updated cart
        HttpSession session = request.getSession();
        session.setAttribute("cart", updatedCart);

        // Save cart to appropriate storage
        saveCart(request, response, updatedCart);

        response.sendRedirect(request.getContextPath() + "/cart?action=view");
    }

    private void deleteCartItem(HttpServletRequest request, HttpServletResponse response)
            throws IOException, SQLException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        List<CartItem> cart = getCart(request, response);

        cart.removeIf(item -> item.getProduct().getProductId() == productId);

        // Save cart to appropriate storage
        saveCart(request, response, cart);

        response.sendRedirect(request.getContextPath() + "/cart?action=view");
    }

    private void viewCart(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Make sure the cart is loaded
        getCart(request, response);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/Cart/Cart.jsp");
        dispatcher.forward(request, response);
    }

    // Save cart to appropriate storage based on user login status
    private void saveCart(HttpServletRequest request, HttpServletResponse response, List<CartItem> cart)
            throws SQLException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Update session cart
        session.setAttribute("cart", cart);

        // If user is logged in, save to database
        if (user != null) {
            cartDao.saveCartToDatabase(user, cart);
        } else {
            // For guest users, save to cookie
            CartCookieUtil.saveCartToCookie(response, cart);
        }
    }

    public void clearCart(HttpServletRequest request, HttpServletResponse response)
            throws SQLException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Xóa giỏ hàng trong session
        session.removeAttribute("cart");

        // Nếu người dùng đã đăng nhập, xóa giỏ hàng trong database
        if (user != null) {
            cartDao.clearUserCart(user.getUserId());
        }

        // Xóa giỏ hàng trong cookie
        CartCookieUtil.clearCartCookie(response);
    }
}
