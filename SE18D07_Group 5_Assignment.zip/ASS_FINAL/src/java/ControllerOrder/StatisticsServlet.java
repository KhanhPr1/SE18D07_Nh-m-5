package ControllerOrder;

import OrderDAO.StatisticsDAO;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import Models.User;

@WebServlet(name = "StatisticsServlet", urlPatterns = {"/statistics"})
public class StatisticsServlet extends HttpServlet {

    private StatisticsDAO statisticsDAO = new StatisticsDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        
        // Kiểm tra đăng nhập và quyền admin
        /*if (currentUser == null || !currentUser.isAdmin()) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }*/
        
        // Lấy số lượng items muốn hiển thị, mặc định là 5
        int limit = 5;
        String limitParam = request.getParameter("limit");
        if (limitParam != null && !limitParam.isEmpty()) {
            try {
                limit = Integer.parseInt(limitParam);
            } catch (NumberFormatException e) {
                // Giữ giá trị mặc định nếu có lỗi
            }
        }
        
        // Lấy dữ liệu thống kê
        List<Map<String, Object>> topProducts = statisticsDAO.getTopSellingProducts(limit);
        List<Map<String, Object>> topBrands = statisticsDAO.getTopSellingBrands(limit);
        List<Map<String, Object>> topCategories = statisticsDAO.getTopSellingCategories(limit);
        List<Map<String, Object>> topUsers = statisticsDAO.getTopSpendingUsers(limit);
        BigDecimal totalRevenue = statisticsDAO.getTotalRevenue();
        List<Map<String, Object>> brandRevenue = statisticsDAO.getBrandRevenuePercentage();
        List<Map<String, Object>> categoryRevenue = statisticsDAO.getCategoryRevenuePercentage();
        
        // Đặt các thuộc tính để hiển thị trong JSP
        request.setAttribute("topProducts", topProducts);
        request.setAttribute("topBrands", topBrands);
        request.setAttribute("topCategories", topCategories);
        request.setAttribute("topUsers", topUsers);
        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("brandRevenue", brandRevenue);
        request.setAttribute("categoryRevenue", categoryRevenue);
        request.setAttribute("limit", limit);
        
        // Chuyển hướng đến trang JSP
        request.getRequestDispatcher("order/statistics.jsp").forward(request, response);
    }
}