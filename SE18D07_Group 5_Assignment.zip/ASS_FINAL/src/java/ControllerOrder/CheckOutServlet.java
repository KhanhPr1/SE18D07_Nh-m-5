package ControllerOrder;

import Models.CartItem;
import Models.Order;
import Models.OrderDetail;
import Models.User;
import OrderDAO.OrderDAO;
import ProductDao.ProductDao;
import com.vnpay.common.Config;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import uitl.EmailService;
import uitl.IJavaMail;

@WebServlet(name = "CheckOutServlet", urlPatterns = {"/checkout"})
public class CheckOutServlet extends HttpServlet {

    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                
        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart?action=view");
            return;
        }

        // Kiểm tra tồn kho từng sản phẩm trong giỏ hàng
        for (CartItem item : cart) {
            int requestedQty = item.getQuantity();
            int stockQty = item.getProduct().getStock();
            if (requestedQty > stockQty) {
                request.setAttribute("errorMessage", "Sản phẩm " + item.getProduct().getProductName()
                        + " chỉ còn " + stockQty + " sản phẩm trong kho. Vui lòng điều chỉnh số lượng.");
                request.getRequestDispatcher("Cart/Cart.jsp").forward(request, response);
                return;
            }
        }

        User currentUser = (User) session.getAttribute("user");
        int userId = currentUser.getUserId();
        BigDecimal totalPrice = BigDecimal.ZERO;
        List<OrderDetail> details = new ArrayList<>();

        for (CartItem item : cart) {
            BigDecimal itemTotal = item.getProduct().getPrice()
                    .multiply(BigDecimal.valueOf(item.getQuantity()));
            totalPrice = totalPrice.add(itemTotal);
            OrderDetail detail = new OrderDetail();
            detail.setProduct(item.getProduct());
            detail.setQuantity(item.getQuantity());
            detail.setPrice(item.getProduct().getPrice());
            details.add(detail);
        }

        // Áp dụng khuyến mãi 10%
        totalPrice = totalPrice.multiply(BigDecimal.valueOf(0.9));

        // Tạo Order với trạng thái "Pending" để chờ thanh toán VNPay
        Order order = new Order();
        order.setUserId(userId);
        order.setTotalPrice(totalPrice);
        order.setStatus("Pending");
        order.setOrderDetails(details);

        int orderId;
        try {
            orderId = orderDAO.insertOrder(order);
            order.setId(orderId);
            orderDAO.insertOrderDetail(order);
            session.setAttribute("orderId", orderId);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi tạo đơn hàng: " + e.getMessage());
            request.getRequestDispatcher("Cart/Cart.jsp").forward(request, response);
            return;
        }

        // Xây dựng URL thanh toán VNPay
        String vnp_Version = "2.1.0";
        String vnp_Command = "pay";
        String orderType = "other";
        // VNPay yêu cầu số tiền tính theo đơn vị nhỏ nhất (ví dụ: nhân 100)
        long amount = totalPrice.multiply(BigDecimal.valueOf(100)).longValue();
        String bankCode = request.getParameter("bankCode");
        String vnp_TxnRef = String.valueOf(orderId);
        String vnp_IpAddr = Config.getIpAddress(request);
        String vnp_TmnCode = Config.vnp_TmnCode;

        Map<String, String> vnp_Params = new HashMap<>();
        vnp_Params.put("vnp_Version", vnp_Version);
        vnp_Params.put("vnp_Command", vnp_Command);
        vnp_Params.put("vnp_TmnCode", vnp_TmnCode);
        vnp_Params.put("vnp_Amount", String.valueOf(amount));
        vnp_Params.put("vnp_CurrCode", "VND");
        if (bankCode != null && !bankCode.isEmpty()) {
            vnp_Params.put("vnp_BankCode", bankCode);
        }
        vnp_Params.put("vnp_TxnRef", vnp_TxnRef);
        vnp_Params.put("vnp_OrderInfo", "Thanh toán đơn hàng: " + vnp_TxnRef);
        vnp_Params.put("vnp_OrderType", orderType);
        String language = request.getParameter("language");
        if (language != null && !language.isEmpty()) {
            vnp_Params.put("vnp_Locale", language);
        } else {
            vnp_Params.put("vnp_Locale", "vn");
        }
        // Sử dụng vnp_ReturnUrl từ Config.java (đã cập nhật với context /ASS_FINAL)
        vnp_Params.put("vnp_ReturnUrl", Config.vnp_ReturnUrl);
        vnp_Params.put("vnp_IpAddr", vnp_IpAddr);

        Calendar cld = Calendar.getInstance(TimeZone.getTimeZone("Etc/GMT+7"));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String vnp_CreateDate = formatter.format(cld.getTime());
        vnp_Params.put("vnp_CreateDate", vnp_CreateDate);
        cld.add(Calendar.MINUTE, 15);
        String vnp_ExpireDate = formatter.format(cld.getTime());
        vnp_Params.put("vnp_ExpireDate", vnp_ExpireDate);

        List<String> fieldNames = new ArrayList<>(vnp_Params.keySet());
        Collections.sort(fieldNames);
        StringBuilder hashData = new StringBuilder();
        StringBuilder query = new StringBuilder();
        for (Iterator<String> itr = fieldNames.iterator(); itr.hasNext();) {
            String fieldName = itr.next();
            String fieldValue = vnp_Params.get(fieldName);
            if (fieldValue != null && fieldValue.length() > 0) {
                hashData.append(fieldName)
                        .append('=')
                        .append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString()));
                query.append(URLEncoder.encode(fieldName, StandardCharsets.US_ASCII.toString()))
                        .append('=')
                        .append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString()));
                if (itr.hasNext()) {
                    hashData.append('&');
                    query.append('&');
                }
            }
        }
        String vnp_SecureHash = Config.hmacSHA512(Config.secretKey, hashData.toString());
        query.append("&vnp_SecureHash=").append(vnp_SecureHash);
        String paymentUrl = Config.vnp_PayUrl + "?" + query.toString();
        
        // Xóa giỏ hàng sau khi thanh toán thành công
            session.removeAttribute("cart");

            CartServlet cartServlet = new CartServlet();
        try {
            cartServlet.clearCart(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(CheckOutServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Chuyển hướng người dùng đến trang thanh toán VNPay
        response.sendRedirect(paymentUrl);

        // --- Code dưới đây là phần xử lý gửi email như cũ,
        // sẽ không được gọi ngay vì bạn đã chuyển hướng sang VNPay.
        // Khi VNPay trả về kết quả, vnpay_return.jsp sẽ xử lý việc gửi email.
    }
}
