package ControllerOrder;

import Models.Order;
import Models.User;
import OrderDAO.OrderDAO;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "OrderListServlet", urlPatterns = {"/order-list"})
public class OrderListServlet extends HttpServlet {

    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        int userId = currentUser.getUserId();
        List<Order> orderList = orderDAO.getOrdersByUserId(userId);

        request.setAttribute("orderList", orderList);
        request.getRequestDispatcher("order/orderList.jsp").forward(request, response);
    }
}
