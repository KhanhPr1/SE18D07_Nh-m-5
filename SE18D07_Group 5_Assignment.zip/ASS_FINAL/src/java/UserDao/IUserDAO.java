
package UserDao;

import Models.User;
import java.sql.SQLException;
import java.util.List;


public interface IUserDAO {

    
    User authenticateUser(String identifier, String password);
    
    
    void insertUser(User user) throws SQLException;
    
    
    List<User> selectAllUsers();
    
    User findById(int id) throws SQLException;
    
    
    boolean deleteUser(int id) throws SQLException;
    
    
    boolean updateUser(User user) throws SQLException;
    
    List<User> searchUsers(String query);
        
    public List<User> filterUsersPaginated(String roleFilter, String statusFilter, int offset, int pageSize, Integer excludeUserId);
    
    public int countUsers(String roleFilter, String statusFilter, Integer excludeUserId);
    
    public boolean isEmailExists(String email);
    
    public User getUserByEmail(String email);
}
