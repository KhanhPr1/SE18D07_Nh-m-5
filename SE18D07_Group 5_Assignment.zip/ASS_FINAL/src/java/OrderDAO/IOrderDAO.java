
package OrderDAO;

import Models.Order;
import java.sql.SQLException;


public interface IOrderDAO {
    int insertOrder(Order order) throws SQLException;
    void insertOrderDetail(Order order) throws SQLException;
    void updateOrderStatus(int orderId, String status) throws SQLException;
    Order getOrderById(int orderId) throws SQLException;
}
