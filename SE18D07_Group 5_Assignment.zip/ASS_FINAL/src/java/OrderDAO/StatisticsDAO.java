package OrderDAO;

import Dao.DBConnection;
import Models.Product;
import Models.Brand;
import Models.Category;
import Models.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatisticsDAO {

    // Lấy top sản phẩm bán chạy nhất
    public List<Map<String, Object>> getTopSellingProducts(int limit) {
        List<Map<String, Object>> products = new ArrayList<>();
        String sql = "SELECT TOP(?) p.product_id, p.product_name, p.price, SUM(od.quantity) as total_sold " +
                     "FROM Products p " +
                     "JOIN OrderDetails od ON p.product_id = od.product_id " +
                     "JOIN Orders o ON od.order_id = o.id " +
                     "GROUP BY p.product_id, p.product_name, p.price " +
                     "ORDER BY total_sold DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, limit);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> product = new HashMap<>();
                    product.put("productId", rs.getInt("product_id"));
                    product.put("productName", rs.getString("product_name"));
                    product.put("price", rs.getBigDecimal("price"));
                    product.put("totalSold", rs.getInt("total_sold"));
                    products.add(product);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return products;
    }
    
    // Lấy top brand bán chạy nhất
    public List<Map<String, Object>> getTopSellingBrands(int limit) {
        List<Map<String, Object>> brands = new ArrayList<>();
        String sql = "SELECT TOP(?) b.brand_id, b.brand_name, SUM(od.quantity) as total_sold, " +
                     "SUM(od.price * od.quantity) as revenue " +
                     "FROM Brands b " +
                     "JOIN Products p ON b.brand_id = p.brand_id " +
                     "JOIN OrderDetails od ON p.product_id = od.product_id " +
                     "JOIN Orders o ON od.order_id = o.id " +
                     "GROUP BY b.brand_id, b.brand_name " +
                     "ORDER BY total_sold DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, limit);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> brand = new HashMap<>();
                    brand.put("brandId", rs.getInt("brand_id"));
                    brand.put("brandName", rs.getString("brand_name"));
                    brand.put("totalSold", rs.getInt("total_sold"));
                    brand.put("revenue", rs.getBigDecimal("revenue"));
                    brands.add(brand);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return brands;
    }
    
    // Lấy top category bán chạy nhất
    public List<Map<String, Object>> getTopSellingCategories(int limit) {
        List<Map<String, Object>> categories = new ArrayList<>();
        String sql = "SELECT TOP(?) c.category_id, c.category_name, SUM(od.quantity) as total_sold, " +
                     "SUM(od.price * od.quantity) as revenue " +
                     "FROM Categories c " +
                     "JOIN Products p ON c.category_id = p.category_id " +
                     "JOIN OrderDetails od ON p.product_id = od.product_id " +
                     "JOIN Orders o ON od.order_id = o.id " +
                     "GROUP BY c.category_id, c.category_name " +
                     "ORDER BY total_sold DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, limit);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> category = new HashMap<>();
                    category.put("categoryId", rs.getInt("category_id"));
                    category.put("categoryName", rs.getString("category_name"));
                    category.put("totalSold", rs.getInt("total_sold"));
                    category.put("revenue", rs.getBigDecimal("revenue"));
                    categories.add(category);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return categories;
    }
    
    // Lấy top khách hàng chi tiêu nhiều nhất - Fixed column name issue
    public List<Map<String, Object>> getTopSpendingUsers(int limit) {
        List<Map<String, Object>> users = new ArrayList<>();
        // Fixed SQL query to use UserID instead of id
        String sql = "SELECT TOP(?) u.UserID as user_id, u.FullName as full_name, u.Email as email, " +
                     "SUM(o.total_price) as total_spent, COUNT(DISTINCT o.id) as order_count " +
                     "FROM Users u " +
                     "JOIN Orders o ON u.UserID = o.user_id " +
                     "WHERE o.status = 'Done' " +
                     "GROUP BY u.UserID, u.FullName, u.Email " +
                     "ORDER BY total_spent DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, limit);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> user = new HashMap<>();
                    user.put("userId", rs.getInt("user_id"));
                    user.put("fullName", rs.getString("full_name"));
                    user.put("email", rs.getString("email"));
                    user.put("totalSpent", rs.getBigDecimal("total_spent"));
                    user.put("orderCount", rs.getInt("order_count"));
                    users.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return users;
    }
    
    // Lấy tổng doanh thu - Fixed query
    public BigDecimal getTotalRevenue() {
        BigDecimal totalRevenue = BigDecimal.ZERO;
        String sql = "SELECT SUM(total_price) as total_revenue FROM Orders WHERE status = 'Done'";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            if (rs.next()) {
                BigDecimal result = rs.getBigDecimal("total_revenue");
                if (result != null) {
                    totalRevenue = result;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalRevenue;
    }
    
    // Lấy doanh thu và phần trăm theo brand - fixed user_id reference
    public List<Map<String, Object>> getBrandRevenuePercentage() {
        List<Map<String, Object>> brandRevenue = new ArrayList<>();
        BigDecimal totalRevenue = getTotalRevenue();
        
        if (totalRevenue.compareTo(BigDecimal.ZERO) == 0) {
            return brandRevenue;
        }
        
        String sql = "SELECT b.brand_id, b.brand_name, SUM(od.price * od.quantity) as revenue " +
                     "FROM Brands b " +
                     "JOIN Products p ON b.brand_id = p.brand_id " +
                     "JOIN OrderDetails od ON p.product_id = od.product_id " +
                     "JOIN Orders o ON od.order_id = o.id " +
                     "WHERE o.status = 'Done' " +
                     "GROUP BY b.brand_id, b.brand_name " +
                     "ORDER BY revenue DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Map<String, Object> brand = new HashMap<>();
                brand.put("brandId", rs.getInt("brand_id"));
                brand.put("brandName", rs.getString("brand_name"));
                BigDecimal revenue = rs.getBigDecimal("revenue");
                brand.put("revenue", revenue);
                
                // Tính phần trăm doanh thu - Fixed divide by zero check
                if (totalRevenue.compareTo(BigDecimal.ZERO) > 0) {
                    BigDecimal percentage = revenue.multiply(new BigDecimal(100)).divide(totalRevenue, 2, BigDecimal.ROUND_HALF_UP);
                    brand.put("percentage", percentage);
                } else {
                    brand.put("percentage", BigDecimal.ZERO);
                }
                
                brandRevenue.add(brand);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return brandRevenue;
    }
    
    // Lấy doanh thu và phần trăm theo category
    public List<Map<String, Object>> getCategoryRevenuePercentage() {
        List<Map<String, Object>> categoryRevenue = new ArrayList<>();
        BigDecimal totalRevenue = getTotalRevenue();
        
        if (totalRevenue.compareTo(BigDecimal.ZERO) == 0) {
            return categoryRevenue;
        }
        
        String sql = "SELECT c.category_id, c.category_name, SUM(od.price * od.quantity) as revenue " +
                     "FROM Categories c " +
                     "JOIN Products p ON c.category_id = p.category_id " +
                     "JOIN OrderDetails od ON p.product_id = od.product_id " +
                     "JOIN Orders o ON od.order_id = o.id " +
                     "WHERE o.status = 'Done' " +
                     "GROUP BY c.category_id, c.category_name " +
                     "ORDER BY revenue DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Map<String, Object> category = new HashMap<>();
                category.put("categoryId", rs.getInt("category_id"));
                category.put("categoryName", rs.getString("category_name"));
                BigDecimal revenue = rs.getBigDecimal("revenue");
                category.put("revenue", revenue);
                
                // Tính phần trăm doanh thu - Fixed divide by zero check
                if (totalRevenue.compareTo(BigDecimal.ZERO) > 0) {
                    BigDecimal percentage = revenue.multiply(new BigDecimal(100)).divide(totalRevenue, 2, BigDecimal.ROUND_HALF_UP);
                    category.put("percentage", percentage);
                } else {
                    category.put("percentage", BigDecimal.ZERO); // FIX THIS LINE
                }
                
                categoryRevenue.add(category);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return categoryRevenue;
    }
}