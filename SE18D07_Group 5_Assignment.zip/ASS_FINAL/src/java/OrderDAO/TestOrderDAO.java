package OrderDAO;

import Models.Order;
import Models.OrderDetail;
import java.util.List;

public class TestOrderDAO {
    public static void main(String[] args) {
        OrderDAO orderDAO = new OrderDAO();
        int userId = 1; // Thay bằng ID user cần kiểm tra

        List<Order> orders = orderDAO.getOrdersByUserId(userId);
        
        if (orders.isEmpty()) {
            System.out.println("Người dùng này chưa có đơn hàng nào.");
        } else {
            System.out.println("Danh sách đơn hàng của UserID: " + userId);
            for (Order order : orders) {
                System.out.println("-----------------------------------");
                System.out.println("Mã đơn hàng: " + order.getId());
                System.out.println("Ngày đặt hàng: " + order.getOrderDate());
                System.out.println("Tổng giá trị: $" + order.getTotalPrice());
                System.out.println("Trạng thái: " + order.getStatus());
                System.out.println("Chi tiết đơn hàng:");
                
                for (OrderDetail detail : order.getOrderDetails()) {
                    System.out.println(" - Sản phẩm: " + detail.getProduct().getProductName());
                    System.out.println("   Số lượng: " + detail.getQuantity());
                    System.out.println("   Giá: $" + detail.getPrice());
                }
            }
        }
    }
}
