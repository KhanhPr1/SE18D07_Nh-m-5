package ProductDao;

import ProductDao.ProductDao;
import Models.Product;
import java.util.List;

public class ProductDaoTest {
    public static void main(String[] args) {
        ProductDao productDao = new ProductDao();
        int page = 1; // Chọn trang muốn test
        int pageSize = 12; // Số sản phẩm trên mỗi trang

        List<Product> products = productDao.getProductsByPage(page, pageSize);
        int totalProducts = productDao.getTotalProducts();
        int totalPages = (int) Math.ceil((double) totalProducts / pageSize);

        System.out.println("Tổng số sản phẩm: " + totalProducts);
        System.out.println("Tổng số trang: " + totalPages);
        System.out.println("Danh sách sản phẩm trang " + page + ":");

        for (Product product : products) {
            System.out.println("ID: " + product.getProductId() +
                               " | Tên: " + product.getProductName() +
                               " | Giá: " + product.getPrice() +
                               " | Stock: " + product.getStock());
        }
    }
}
