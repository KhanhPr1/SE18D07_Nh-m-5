package ProductDao;

import Dao.DBConnection;
import Models.CartItem;
import Models.Product;
import Models.User;
import ProductDao.ProductDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CartDao {
    private static final String INSERT_CART_ITEM = "INSERT INTO UserCartItems (user_id, product_id, quantity) VALUES (?, ?, ?)";
    private static final String UPDATE_CART_ITEM = "UPDATE UserCartItems SET quantity = ? WHERE user_id = ? AND product_id = ?";
    private static final String SELECT_CART_ITEMS = "SELECT product_id, quantity FROM UserCartItems WHERE user_id = ?";
    private static final String DELETE_CART_ITEM = "DELETE FROM UserCartItems WHERE user_id = ? AND product_id = ?";
    private static final String CLEAR_USER_CART = "DELETE FROM UserCartItems WHERE user_id = ?";
    private static final String CHECK_CART_ITEM_EXISTS = "SELECT COUNT(*) FROM UserCartItems WHERE user_id = ? AND product_id = ?";
    
    // Save cart to database
    public void saveCartToDatabase(User user, List<CartItem> cart) throws SQLException {
        // First clear any existing cart items for this user
        clearUserCart(user.getUserId());
        
        // Then add all current items
        for (CartItem item : cart) {
            addCartItem(user.getUserId(), item.getProduct().getProductId(), item.getQuantity());
        }
    }
    
    // Add a single item to cart
    public void addCartItem(int userId, int productId, int quantity) throws SQLException {
        if (cartItemExists(userId, productId)) {
            updateCartItem(userId, productId, quantity);
        } else {
            try (Connection connection = DBConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(INSERT_CART_ITEM)) {
                statement.setInt(1, userId);
                statement.setInt(2, productId);
                statement.setInt(3, quantity);
                statement.executeUpdate();
            }
        }
    }
    
    // Update a cart item quantity
    public void updateCartItem(int userId, int productId, int quantity) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_CART_ITEM)) {
            statement.setInt(1, quantity);
            statement.setInt(2, userId);
            statement.setInt(3, productId);
            statement.executeUpdate();
        }
    }
    
    // Check if a cart item exists for a user
    public boolean cartItemExists(int userId, int productId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(CHECK_CART_ITEM_EXISTS)) {
            statement.setInt(1, userId);
            statement.setInt(2, productId);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }
    
    // Get cart items for a user
    public List<CartItem> getCartItems(int userId) {
        List<CartItem> cartItems = new ArrayList<>();
        ProductDao productDao = new ProductDao();
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_CART_ITEMS)) {
            statement.setInt(1, userId);
            ResultSet rs = statement.executeQuery();
            
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                
                Product product = productDao.selectProduct(productId);
                if (product != null) {
                    cartItems.add(new CartItem(product, quantity));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return cartItems;
    }
    
    // Delete a cart item
    public void deleteCartItem(int userId, int productId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_CART_ITEM)) {
            statement.setInt(1, userId);
            statement.setInt(2, productId);
            statement.executeUpdate();
        }
    }
    
    // Clear all cart items for a user
    public void clearUserCart(int userId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(CLEAR_USER_CART)) {
            statement.setInt(1, userId);
            statement.executeUpdate();
        }
    }
}