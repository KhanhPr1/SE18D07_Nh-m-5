
package ProductDao;

import java.sql.SQLException;
import Models.Brand;
import java.util.List;


public interface IBrandDao {
    void insertBrand(Brand brand) throws SQLException;
    
    Brand selectBrand(int id) throws SQLException;
    
    List<Brand> selectAllBrands() throws SQLException;
    
    boolean updateBrand(Brand brand) throws SQLException;
    
    boolean deleteBrand(int id) throws SQLException;
}
