
package UserDao;

import Models.User;
import Dao.DBConnection;
import Models.Role;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO implements IUserDAO {

    @Override
    public User authenticateUser(String identifier, String password) {

        User user = null;

        String sql = "SELECT u.UserID, u.Username, u.Email, u.Password, u.FullName, "
                + "       u.PhoneNumber, u.Avatar, u.Score, u.Sex, "
                + "       u.BirthDate, u.CreatedAt, u.UpdatedAt, u.Locked, "
                + "       r.RoleID AS RoleId, r.RoleName, r.Description "
                + "FROM [Users] u "
                + "INNER JOIN Roles r ON u.RoleId = r.RoleID "
                + "WHERE (u.Username = ? OR u.Email = ? OR u.PhoneNumber = ?) AND u.password = ?";

        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, identifier);
            stmt.setString(2, identifier);
            stmt.setString(3, identifier);
            stmt.setString(4, password);

            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {

                    Role role = new Role(rs.getInt("RoleId"),
                            rs.getString("RoleName"),
                            rs.getString("Description"));

                    user = new User();
                    user.setUserId(rs.getInt("UserID"));
                    user.setRole(role);
                    user.setUsername(rs.getString("Username"));
                    user.setEmail(rs.getString("Email"));
                    user.setPassword(rs.getString("Password"));
                    user.setFullName(rs.getString("FullName"));
                    user.setPhoneNumber(rs.getString("PhoneNumber"));
                    user.setAvatar(rs.getString("Avatar"));
                    user.setScore(rs.getInt("Score"));
                    user.setSex(rs.getString("Sex"));
                    user.setBirthDate(rs.getDate("BirthDate"));
                    user.setCreatedAt(rs.getTimestamp("createdAt"));
                    user.setUpdatedAt(rs.getTimestamp("updatedAt"));
                    user.setLocked(rs.getBoolean("Locked"));
                }
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
        return user;
    }

    @Override
    public void insertUser(User user) throws SQLException {

        String sql = "INSERT INTO [Users] (Username, Email, Password, FullName, RoleId, PhoneNumber, "
                + "Avatar, Score, Sex, BirthDate, CreatedAt, UpdatedAt, Locked) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE(), GETDATE(), ?)";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());

            stmt.setString(2, user.getEmail());

            stmt.setString(3, user.getPassword());

            stmt.setString(4, user.getFullName());

            stmt.setInt(5, user.getRole().getRoleId());

            stmt.setString(6, user.getPhoneNumber());

            stmt.setString(7, user.getAvatar());

            stmt.setInt(8, user.getScore());

            stmt.setString(9, user.getSex());

            stmt.setDate(10, new java.sql.Date(user.getBirthDate().getTime()));

            stmt.setBoolean(11, user.isLocked());

            stmt.executeUpdate();

        }
    }

    @Override
    public List<User> selectAllUsers() {

        List<User> userList = new ArrayList<>();

        String sql = " SELECT u.UserID, u.Username, u.Email, u.Password, u.FullName, "
                + "       u.PhoneNumber, u.Avatar, u.Score, u.Sex, "
                + "       u.BirthDate, u.CreatedAt, u.UpdatedAt, u.Locked, "
                + "       r.RoleID AS RoleId, r.RoleName, r.Description "
                + "FROM [Users] u "
                + "INNER JOIN Roles r ON u.RoleId = r.RoleID ";

        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(sql); 
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Role role = new Role(rs.getInt("roleId"),
                        rs.getString("roleName"),
                        rs.getString("Description")
                );
                User user = new User();

                user.setUserId(rs.getInt("UserID"));
                user.setRole(role);
                user.setUsername(rs.getString("Username"));
                user.setEmail(rs.getString("Email"));
                user.setPassword(rs.getString("Password"));
                user.setFullName(rs.getString("FullName"));
                user.setPhoneNumber(rs.getString("PhoneNumber"));
                user.setAvatar(rs.getString("Avatar"));
                user.setScore(rs.getInt("Score"));
                user.setSex(rs.getString("Sex"));
                user.setBirthDate(rs.getDate("BirthDate"));
                user.setCreatedAt(rs.getTimestamp("createdAt"));
                user.setUpdatedAt(rs.getTimestamp("updatedAt"));
                user.setLocked(rs.getBoolean("Locked"));

                userList.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userList;
    }

    @Override
    public User findById(int id) throws SQLException {

        User user = null;

        String sql = " SELECT u.UserID, u.Username, u.Email, u.Password, u.FullName, "
                + "       u.PhoneNumber, u.Avatar, u.Score, u.Sex, "
                + "       u.BirthDate, u.CreatedAt, u.UpdatedAt, u.Locked, "
                + "       r.RoleID AS RoleId, r.RoleName, r.Description "
                + "FROM [Users] u "
                + "INNER JOIN Roles r ON u.RoleId = r.RoleID WHERE UserID = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql);) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {

                    Role role = new Role(rs.getInt("roleId"),
                            rs.getString("roleName"),
                            rs.getString("Description")
                    );
                    user = new User();

                    user.setUserId(rs.getInt("UserID"));
                    user.setRole(role);
                    user.setUsername(rs.getString("Username"));
                    user.setEmail(rs.getString("Email"));
                    user.setPassword(rs.getString("Password"));
                    user.setFullName(rs.getString("FullName"));
                    user.setPhoneNumber(rs.getString("PhoneNumber"));
                    user.setAvatar(rs.getString("Avatar"));
                    user.setScore(rs.getInt("Score"));
                    user.setSex(rs.getString("Sex"));
                    user.setBirthDate(rs.getDate("BirthDate"));
                    user.setCreatedAt(rs.getTimestamp("createdAt"));
                    user.setUpdatedAt(rs.getTimestamp("updatedAt"));
                    user.setLocked(rs.getBoolean("Locked"));
                }
            }
        }
        return user;
    }

    @Override
    public boolean deleteUser(int id) throws SQLException {
        String sql = "DELETE FROM [Users] WHERE UserID = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);

            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE [Users] SET Username = ?, Email = ?, Password = ?, FullName = ?, RoleId = ?, PhoneNumber = ?, UpdatedAt = GETDATE(), Locked = ?, Avatar = ?, Score = ?, Sex = ?, BirthDate = ?  WHERE UserID = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getPassword());
            stmt.setString(4, user.getFullName());
            stmt.setInt(5, user.getRole().getRoleId());
            stmt.setString(6, user.getPhoneNumber());
            stmt.setBoolean(7, user.isLocked());
            stmt.setString(8, user.getAvatar());
            stmt.setInt(9, user.getScore());
            stmt.setString(10, user.getSex());
            stmt.setDate(11, new java.sql.Date(user.getBirthDate().getTime()));
            stmt.setInt(12, user.getUserId());

            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public List<User> searchUsers(String query) {

        List<User> userList = new ArrayList<>();

        String sql = "SELECT u.UserID, u.Username, u.Email, u.Password, u.FullName, "
                + "       u.PhoneNumber, u.Avatar, u.Score, u.Sex, "
                + "       u.BirthDate, u.CreatedAt, u.UpdatedAt, u.Locked, "
                + "       r.RoleID AS RoleId, r.RoleName, r.Description "
                + "FROM [Users] u "
                + "INNER JOIN Roles r ON u.RoleId = r.RoleID "
                + "WHERE u.username LIKE ? OR u.email LIKE ? OR u.fullName LIKE ? OR u.phoneNumber LIKE ?";

        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            String likeQuery = "%" + query + "%";

            stmt.setString(1, likeQuery);
            stmt.setString(2, likeQuery);
            stmt.setString(3, likeQuery);
            stmt.setString(4, likeQuery);

            try (ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {

                    Role role = new Role(rs.getInt("RoleID"),
                            rs.getString("RoleName"),
                            rs.getString("Description"));

                    User user = new User();
                    user.setUserId(rs.getInt("UserID"));
                    user.setRole(role);
                    user.setUsername(rs.getString("Username"));
                    user.setEmail(rs.getString("Email"));
                    user.setPassword(rs.getString("Password"));
                    user.setFullName(rs.getString("FullName"));
                    user.setPhoneNumber(rs.getString("PhoneNumber"));
                    user.setAvatar(rs.getString("Avatar"));
                    user.setScore(rs.getInt("Score"));
                    user.setSex(rs.getString("Sex"));
                    user.setBirthDate(rs.getDate("BirthDate"));
                    user.setCreatedAt(rs.getTimestamp("CreatedAt"));
                    user.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                    user.setLocked(rs.getBoolean("Locked"));

                    userList.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }
   

    @Override
    public List<User> filterUsersPaginated(String roleFilter, String statusFilter, int offset, int pageSize, Integer excludeUserId) {
        List<User> userList = new ArrayList<>();
        String sql = "SELECT u.UserID, u.Username, u.Email, u.Password, u.FullName, "
                + "       u.PhoneNumber, u.CreatedAt, u.UpdatedAt, u.BirthDate,"
                + "u.Locked, u.Avatar, "
                + "       r.RoleID AS RoleId, r.RoleName "
                + "FROM [Users] u INNER JOIN Roles r ON u.RoleId = r.RoleID ";

        List<String> conditions = new ArrayList<>();
        if (!"all".equalsIgnoreCase(roleFilter)) {
            conditions.add("r.RoleName = ?");
        }
        if (!"all".equalsIgnoreCase(statusFilter)) {
            if ("active".equalsIgnoreCase(statusFilter)) {
                conditions.add("u.Locked = 0");
            } else if ("locked".equalsIgnoreCase(statusFilter)) {
                conditions.add("u.Locked = 1");
            }
        }
        if (excludeUserId != null) {
            conditions.add("u.UserID <> ?");
        }

        if (!conditions.isEmpty()) {
            sql += "WHERE " + String.join(" AND ", conditions) + " ";
        }

        sql += "ORDER BY "
                + "CASE WHEN r.RoleName = 'admin' THEN 0 ELSE 1 END, "
                + "CASE WHEN u.Locked = 0 THEN 0 ELSE 1 END, "
                + "u.Username ASC "
                + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

        try (Connection conn = DBConnection.getConnection(); 
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            int index = 1;
            if (!"all".equalsIgnoreCase(roleFilter)) {
                stmt.setString(index++, roleFilter);
            }
            if (excludeUserId != null) {
                stmt.setInt(index++, excludeUserId);
            }
            stmt.setInt(index++, offset);
            stmt.setInt(index++, pageSize);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Role role = new Role(rs.getInt("RoleId"), rs.getString("RoleName"));
                    User user = new User();
                    user.setUserId(rs.getInt("UserID"));
                    user.setUsername(rs.getString("Username"));
                    user.setEmail(rs.getString("Email"));
                    user.setPassword(rs.getString("Password"));
                    user.setFullName(rs.getString("FullName"));
                    user.setPhoneNumber(rs.getString("PhoneNumber"));
                    user.setBirthDate(rs.getDate("BirthDate"));
                    user.setCreatedAt(rs.getTimestamp("CreatedAt"));
                    user.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                    user.setLocked(rs.getBoolean("Locked"));
                    user.setAvatar(rs.getString("Avatar"));
                    user.setRole(role);
                    userList.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userList;
    }

    @Override
    public int countUsers(String roleFilter, String statusFilter, Integer excludeUserId) {
        int count = 0;
        String sql = "SELECT COUNT(*) AS total FROM [Users] u INNER JOIN Roles r ON u.RoleId = r.RoleID ";

        List<String> conditions = new ArrayList<>();
        if (!"all".equalsIgnoreCase(roleFilter)) {
            conditions.add("r.RoleName = ?");
        }
        if (!"all".equalsIgnoreCase(statusFilter)) {
            if ("active".equalsIgnoreCase(statusFilter)) {
                conditions.add("u.Locked = 0");
            } else if ("locked".equalsIgnoreCase(statusFilter)) {
                conditions.add("u.Locked = 1");
            }
        }
        if (excludeUserId != null) {
            conditions.add("u.UserID <> ?");
        }

        if (!conditions.isEmpty()) {
            sql += "WHERE " + String.join(" AND ", conditions);
        }

        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            int index = 1;
            if (!"all".equalsIgnoreCase(roleFilter)) {
                stmt.setString(index++, roleFilter);
            }
            if (excludeUserId != null) {
                stmt.setInt(index++, excludeUserId);
            }
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt("total");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public boolean isEmailExists(String email) {
        boolean exists = false;
        // Chuẩn hóa email: loại bỏ khoảng trắng và chuyển thành chữ thường
        String normalizedEmail = email.replaceAll("\\s+", "").toLowerCase();
        String sql = "SELECT COUNT(*) AS count FROM [Users] WHERE REPLACE(email, ' ', '') = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, normalizedEmail);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    exists = rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exists;
    }

    @Override
    public User getUserByEmail(String email) {
        User user = null;
        String normalizedEmail = email.replaceAll("\\s+", "").toLowerCase();
        String sql = "SELECT u.UserID, u.Username, u.Email, u.Password, u.FullName, "
                + "       u.PhoneNumber, u.CreatedAt, u.UpdatedAt, u.Locked, u.Avatar, "
                + "       r.RoleID AS RoleId, r.RoleName "
                + "FROM [Users] u INNER JOIN Roles r ON u.RoleId = r.RoleID "
                + "WHERE REPLACE(u.email, ' ', '') = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, normalizedEmail);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Role role = new Role(rs.getInt("RoleId"), rs.getString("RoleName"));
                    user = new User();
                    user.setUserId(rs.getInt("UserID"));
                    user.setUsername(rs.getString("Username"));
                    user.setEmail(rs.getString("Email"));
                    user.setPassword(rs.getString("Password"));
                    user.setFullName(rs.getString("FullName"));
                    user.setPhoneNumber(rs.getString("PhoneNumber"));
                    user.setCreatedAt(rs.getTimestamp("CreatedAt"));
                    user.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                    user.setLocked(rs.getBoolean("Locked"));
                    user.setAvatar(rs.getString("Avatar"));
                    user.setRole(role);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

}
