
package Listener;

import Models.User;
import jakarta.servlet.ServletContext;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionAttributeListener;
import jakarta.servlet.http.HttpSessionBindingEvent;

@WebListener
public class RoleLoginCounterListener implements HttpSessionAttributeListener {

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {
        if ("user".equals(event.getName())) {
            User user = (User) event.getValue();
            ServletContext context = event.getSession().getServletContext();

            // Lấy số lượng hiện tại, nếu chưa có thì khởi tạo là 0
            Integer loggedInUsers = (Integer) context.getAttribute("loggedInUsers");
            Integer loggedInManagers = (Integer) context.getAttribute("loggedInManagers");
            if (loggedInUsers == null) {
                loggedInUsers = 0;
            }
            if (loggedInManagers == null) {
                loggedInManagers = 0;
            }

            // Nếu role là Manager, tăng số manager, ngược lại tăng số user
            if (user.getRole() != null && "Manager".equalsIgnoreCase(user.getRole().getRoleName())) {
                loggedInManagers++;
            } else {
                loggedInUsers++;
            }
            
            context.setAttribute("loggedInUsers", loggedInUsers);
            context.setAttribute("loggedInManagers", loggedInManagers);
            context.setAttribute("totalLoggedIn", loggedInUsers + loggedInManagers);
        }
    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent event) {
        if ("user".equals(event.getName())) {
            User user = (User) event.getValue();
            ServletContext context = event.getSession().getServletContext();

            Integer loggedInUsers = (Integer) context.getAttribute("loggedInUsers");
            Integer loggedInManagers = (Integer) context.getAttribute("loggedInManagers");
            if (loggedInUsers == null) {
                loggedInUsers = 0;
            }
            if (loggedInManagers == null) {
                loggedInManagers = 0;
            }

            if (user.getRole() != null && "Manager".equalsIgnoreCase(user.getRole().getRoleName())) {
                if (loggedInManagers > 0) {
                    loggedInManagers--;
                }
            } else {
                if (loggedInUsers > 0) {
                    loggedInUsers--;
                }
            }

            context.setAttribute("loggedInUsers", loggedInUsers);
            context.setAttribute("loggedInManagers", loggedInManagers);
            context.setAttribute("totalLoggedIn", loggedInUsers + loggedInManagers);
        }
    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent event) {
        // Bạn có thể xử lý logic attributeReplaced nếu cần
    }
}
