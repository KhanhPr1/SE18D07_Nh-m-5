
package ServiceUser;

import Models.User;
import UserDao.UserDAO;




public class loginService {
    
    private UserDAO userDao = new UserDAO();

    // Phương thức xác thực đăng nhập
    public User authenticate(String identifier, String password) {
        return userDao.authenticateUser(identifier, password);
    }
}
