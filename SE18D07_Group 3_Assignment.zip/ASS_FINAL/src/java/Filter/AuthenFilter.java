package Filter;

import Models.Role;
import Models.User;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;  
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter(filterName = "AuthenFilter", urlPatterns = {"/*"})
public class AuthenFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String uri = req.getRequestURI();

        // Loại trừ các trang/tài nguyên không cần kiểm tra:
        // Cho phép truy cập các trang login, register, logout, 403, file tĩnh,
        // và đặc biệt cho phép bất kỳ URL nào chứa "vnpay_return.jsp"
        if (uri.endsWith("login.jsp")
                || uri.endsWith("/login")
                || uri.endsWith("/register.jsp")
                || uri.endsWith("/register")
                || uri.endsWith("/logout")
                || uri.endsWith("403.jsp")
                || uri.endsWith("productInfo.jsp")
                || uri.contains("/css/")
                || uri.contains("/js/")
                || uri.endsWith("/cart")
                || uri.endsWith("/")
                || uri.endsWith("OrderSuccess.jsp")
                || uri.contains("/img/")
                || uri.contains("vnpay_return.jsp")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        System.out.println("AuthenFilter: Requested URI: " + uri);
        System.out.println("AuthenFilter: Session exists: " + (session != null));
        if (session != null) {
            System.out.println("AuthenFilter: Session ID: " + session.getId());
            System.out.println("AuthenFilter: User in session: " + session.getAttribute("user"));
        }

        // Nếu session null hoặc không có user, cho phép truy cập trang home, ngược lại chuyển hướng login
        if (session == null || session.getAttribute("user") == null) {
            if (uri.contains("/home") || uri.endsWith("home.jsp") || uri.equals(req.getContextPath() + "/")) {
                chain.doFilter(request, response);
                return;
            } else {
                res.sendRedirect(req.getContextPath() + "/authenticator_authorization/login.jsp");
                return;
            }
        }

        // Nếu đã đăng nhập, lấy role và kiểm tra quyền
        User a = (User) session.getAttribute("user");
        Role role = a.getRole();

        if (role.getRoleId() == 1) {  // Admin: cho phép tất cả
            chain.doFilter(request, response);
        } else if (role.getRoleId() == 2) {  // Manager
            if (uri.contains("/checkout") || uri.contains("/cart")
                    || uri.contains("/home") || uri.endsWith("navAdmin.jsp")
                    || uri.contains("/profile") || uri.endsWith("home.jsp")
                    || uri.contains("/product")
                    // Cho phép truy cập trang vnpay_return.jsp
                    || uri.contains("vnpay_return.jsp")) {
                chain.doFilter(request, response);
            } else {
                res.sendRedirect(req.getContextPath() + "/authenticator_authorization/login.jsp");
            }
        } else {  // User thường hoặc các role khác
            if (uri.contains("/checkout") || uri.contains("/cart")
                    || uri.contains("/home") || uri.endsWith("navAdmin.jsp")
                    || uri.contains("/profile") || uri.endsWith("home.jsp")
                    || uri.contains("/order-list") || uri.endsWith("OrderList.jsp")
                    // Cho phép truy cập trang vnpay_return.jsp
                    || uri.contains("vnpay_return.jsp")) {
                chain.doFilter(request, response);
            } else {
                res.sendRedirect(req.getContextPath() + "/authenticator_authorization/login.jsp");
            }
        }
    }
}
