package ControllerUser;

import Models.CartItem;
import Utilities.CartCookieUtil;

import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;

@WebServlet(name = "logoutServlet", urlPatterns = {"/logout"})
public class logoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
          // Xóa giỏ hàng trước khi đăng xuất
        session.removeAttribute("cart");
        
        // Xóa cookie giỏ hàng
        CartCookieUtil.clearCartCookie(response);
        
        // Xóa toàn bộ session (đăng xuất)
        session.invalidate();
        
        
        response.sendRedirect(request.getContextPath() + "/home");
    }
}