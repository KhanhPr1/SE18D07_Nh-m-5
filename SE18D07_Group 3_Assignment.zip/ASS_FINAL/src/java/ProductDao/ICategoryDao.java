
package ProductDao;

import Models.Category;
import java.sql.SQLException;
import java.util.List;

public interface ICategoryDao {
    void insertCategory(Category category) throws SQLException;
    
    Category selectCategory(int id) throws SQLException;
    
    List<Category> selectAllCategories() throws SQLException;
    
    boolean updateCategory(Category category) throws SQLException;
    
    boolean deleteCategory(int id) throws SQLException;
}
