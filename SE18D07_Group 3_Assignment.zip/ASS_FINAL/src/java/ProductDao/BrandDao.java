
package ProductDao;

import Dao.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Models.Brand;
import java.util.ArrayList;
import java.util.List;


public class BrandDao implements IBrandDao{
    private static final String INSERT_BRAND_SQL = "INSERT INTO Brands (brand_name, description) VALUES (?, ?)";
    private static final String SELECT_BRAND_BY_ID = "SELECT brand_id, brand_name, description, created_at, updated_at FROM Brands WHERE brand_id = ?";
    private static final String SELECT_ALL_BRANDS = "SELECT brand_id, brand_name, description, created_at, updated_at FROM Brands";
    private static final String UPDATE_BRAND_SQL = "UPDATE Brands SET brand_name = ?, description = ?, updated_at = GETDATE() WHERE brand_id = ?";
    private static final String DELETE_BRAND_SQL = "DELETE FROM Brands WHERE brand_id = ?";
    
    @Override
    public void insertBrand(Brand brand) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_BRAND_SQL)) {
            preparedStatement.setString(1, brand.getBrandName());
            preparedStatement.setString(2, brand.getDescription());
            preparedStatement.executeUpdate();
        }
    }

    @Override
    public Brand selectBrand(int id) {
        Brand brand = null;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BRAND_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                String brandName = rs.getString("brand_name");
                String description = rs.getString("description");
                // Có thể lấy thêm created_at, updated_at nếu cần
                brand = new Brand(id, brandName);
                brand.setDescription(description);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return brand;
    }

    @Override
    public List<Brand> selectAllBrands() {
        List<Brand> brands = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_BRANDS)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("brand_id");
                String brandName = rs.getString("brand_name");
                String description = rs.getString("description");
                Brand brand = new Brand(id, brandName);
                brand.setDescription(description);
                brands.add(brand);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return brands;
    }

    @Override
    public boolean updateBrand(Brand brand) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_BRAND_SQL)) {
            statement.setString(1, brand.getBrandName());
            statement.setString(2, brand.getDescription());
            statement.setInt(3, brand.getBrandId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    @Override
    public boolean deleteBrand(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_BRAND_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }
}