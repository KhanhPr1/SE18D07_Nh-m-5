
package Validation;

import UserDao.UserDAO;


public class UserValidation {
     /**
     * Kiểm tra số điện thoại phải 10-12 chữ số.
     * @param phoneNumber Số điện thoại cần kiểm tra.
     * @return true nếu đúng định dạng, false nếu sai.
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {
    // Kiểm tra không null và khớp với regex cho 10-12 chữ số
    return phoneNumber != null && phoneNumber.matches("\\d{10,12}");
}


    /**
     * Kiểm tra độ mạnh của password: 
     * - Ít nhất 1 chữ in hoa,
     * - Ít nhất 1 chữ in thường,
     * - Ít nhất 1 số,
     * - Ít nhất 1 kí tự đặc biệt (như @#$%^&+=!),
     * - Và tối thiểu 8 ký tự (có thể thay đổi theo yêu cầu).
     * @param password Password cần kiểm tra.
     * @return true nếu password đạt yêu cầu, false nếu không.
     */
    public static boolean isValidPassword(String password) {
        if (password == null) return false;
        // Regex mẫu: 
        // (?=.*[a-z])       : ít nhất 1 chữ in thường
        // (?=.*[A-Z])       : ít nhất 1 chữ in hoa
        // (?=.*\\d)         : ít nhất 1 số
        // (?=.*[@#$%^&+=!]) : ít nhất 1 kí tự đặc biệt
        // .{8,}             : tối thiểu 8 ký tự
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return password.matches(passwordPattern);
    }

    /**
     * Kiểm tra score không được âm.
     * @param score Giá trị score cần kiểm tra.
     * @return true nếu score >= 0, false nếu không.
     */
    public static boolean isValidScore(int score) {
        return score >= 0;
    }

    /**
     * Kiểm tra email có duy nhất trong hệ thống.
     * Phương thức này sử dụng UserDAO để tra cứu email trong cơ sở dữ liệu.
     * @param email Email cần kiểm tra.
     * @return true nếu email chưa tồn tại, false nếu đã tồn tại.
     */
    public static boolean isEmailUnique(String email) {
        // Lưu ý: Nên xử lý normalize email nếu cần (loại bỏ khoảng trắng, chuyển thành chữ thường).
        UserDAO userDao = new UserDAO();
        return !userDao.isEmailExists(email);
    }
}
