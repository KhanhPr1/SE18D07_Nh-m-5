package ControllerProduct;

import Models.Product;
import Models.User;
import ProductDao.ProductDao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "HomeServlet", urlPatterns = {"/home"})
public class HomeServlet extends HttpServlet {

    private ProductDao productDao;

    @Override
    public void init() {
        productDao = new ProductDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            boolean isAdmin = currentUser != null && currentUser.getRole().getRoleName().equalsIgnoreCase("admin");

            // Lấy từ khóa tìm kiếm từ request
            String keyword = request.getParameter("keyword");

            List<Product> products;
            if (keyword != null && !keyword.trim().isEmpty()) {
                products = productDao.searchProducts(keyword); // Gọi phương thức tìm kiếm
            } else {
                products = productDao.selectAllProducts(isAdmin); // Hiển thị toàn bộ sản phẩm nếu không có từ khóa
            }

            request.setAttribute("products", products);
            request.setAttribute("keyword", keyword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
        dispatcher.forward(request, response);
    }

}
