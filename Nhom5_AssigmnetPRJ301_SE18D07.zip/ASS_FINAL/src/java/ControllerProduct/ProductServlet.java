package ControllerProduct;

import Models.Brand;
import Models.Category;
import Models.Product;
import Models.Role;
import Models.User;
import ProductDao.BrandDao;
import ProductDao.CategoryDao;
import ProductDao.ProductDao;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.List;

@WebServlet(name = "ProductServlet", urlPatterns = {"/product"})
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50 // 50MB
)
public class ProductServlet extends HttpServlet {

    private ProductDao productDAO;

    @Override
    public void init() {
        productDAO = new ProductDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }

        // Kiểm tra phân quyền (giả sử User có role "admin" hoặc "user")
        User currentUser = (User) request.getSession().getAttribute("user");
        Role role = currentUser.getRole();

        try {
            switch (action) {
                case "list":
                    listProduct(request, response);
                    break;
                case "create":
                    if (!role.getRoleName().equalsIgnoreCase("admin")) {
                        response.sendRedirect(request.getContextPath() + "/authenticator_authorization/403.jsp");
                        return;
                    }
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteProduct(request, response);
                    break;
                case "hide":
                    hideProduct(request, response);
                    break;
                case "show":
                    showProduct(request, response);
                    break;
                default:
                    listProduct(request, response);
                    break;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    // Ẩn sản phẩm (chuyển trạng thái thành "Unavailable")
private void hideProduct(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException {
    int id = Integer.parseInt(request.getParameter("id"));
    productDAO.updateProductStatus(id, "Unavailable");
    response.sendRedirect(request.getContextPath() + "/product?action=list");
}

// Hiển thị sản phẩm (chuyển trạng thái thành "Available")
private void showProduct(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException {
    int id = Integer.parseInt(request.getParameter("id"));
    productDAO.updateProductStatus(id, "Available");
    response.sendRedirect(request.getContextPath() + "/product?action=list");
}


        @Override
        protected void doPost
        (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String action = request.getParameter("action");
            if (action == null) {
                action = "";
            }
            try {
                switch (action) {
                    case "create":
                        insertProduct(request, response);
                        break;
                    case "edit":
                        updateProduct(request, response);
                        break;
                    default:
                        response.sendRedirect(request.getContextPath() + "/product?action=list");
                        break;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        // Hiển thị danh sách sản phẩm
    private void listProduct(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {

        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        boolean isAdmin = currentUser != null && currentUser.getRole().getRoleName().equalsIgnoreCase("admin");

        List<Product> products = productDAO.selectAllProducts(isAdmin);
        request.setAttribute("products", products);
        RequestDispatcher dispatcher = request.getRequestDispatcher("product/ProductList.jsp");
        dispatcher.forward(request, response);
    }

    // Hiển thị form tạo mới sản phẩm (bao gồm dropdown cho Brand và Category)
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        BrandDao brandDao = new BrandDao();
        CategoryDao categoryDao = new CategoryDao();
        List<Brand> brands = brandDao.selectAllBrands();
        List<Category> categories = categoryDao.selectAllCategories();

        request.setAttribute("brands", brands);
        request.setAttribute("categories", categories);
        RequestDispatcher dispatcher = request.getRequestDispatcher("product/CreateProduct.jsp");
        dispatcher.forward(request, response);
    }

    // Xử lý tạo mới sản phẩm
    private void insertProduct(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        BigDecimal price = new BigDecimal(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        String status = request.getParameter("status");

        // Lấy thông tin Brand và Category từ form
        int brandId = Integer.parseInt(request.getParameter("brandId"));
        int categoryId = Integer.parseInt(request.getParameter("categoryId"));
        Brand brand = new Brand(brandId, "");       // Chỉ định ID, tên có thể được lấy sau nếu cần
        Category category = new Category(categoryId, "");

        // Xử lý upload ảnh
        Part filePart = request.getPart("image");
        String fileName = "";
        if (filePart != null && filePart.getSize() > 0) {
            fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String uploadPath = getServletContext().getRealPath("") + File.separator + "img";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }
            filePart.write(uploadPath + File.separator + fileName);
        }
        String imagePath = fileName.isEmpty() ? "default_product.jpg" : fileName;

        // Khởi tạo thời gian tạo và cập nhật
        Timestamp now = new Timestamp(System.currentTimeMillis());

        Product newProduct = new Product(productName, description, price, stock, status, brand, category, imagePath, now, now);
        productDAO.insertProduct(newProduct);
        response.sendRedirect(request.getContextPath() + "/product?action=list");
    }

    // Hiển thị form chỉnh sửa sản phẩm
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Product existingProduct = productDAO.selectProduct(id);

        BrandDao brandDao = new BrandDao();
        CategoryDao categoryDao = new CategoryDao();
        List<Brand> brands = brandDao.selectAllBrands();
        List<Category> categories = categoryDao.selectAllCategories();

        request.setAttribute("brands", brands);
        request.setAttribute("categories", categories);
        request.setAttribute("product", existingProduct);
        RequestDispatcher dispatcher = request.getRequestDispatcher("product/EditProduct.jsp");
        dispatcher.forward(request, response);
    }

    // Xử lý cập nhật sản phẩm
    private void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int productId = Integer.parseInt(request.getParameter("id"));
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        BigDecimal price = new BigDecimal(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        String status = request.getParameter("status");

        int brandId = Integer.parseInt(request.getParameter("brandId"));
        int categoryId = Integer.parseInt(request.getParameter("categoryId"));
        Brand brand = new Brand(brandId, "");
        Category category = new Category(categoryId, "");

        // Xử lý file upload nếu có ảnh mới
        Part filePart = request.getPart("image");
        String fileName = "";
        String imagePath = "";
        if (filePart != null && filePart.getSize() > 0) {
            fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String uploadPath = getServletContext().getRealPath("") + File.separator + "img";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }
            filePart.write(uploadPath + File.separator + fileName);
            imagePath =fileName;
        } else {
            imagePath = request.getParameter("existingImage");
        }

        Timestamp updatedAt = new Timestamp(System.currentTimeMillis());

        Product product = new Product(productId, productName, description, price, stock, status, brand, category, imagePath, null, updatedAt);
        productDAO.updateProduct(product);
        response.sendRedirect(request.getContextPath() + "/product?action=list");
    }

    // Xử lý xoá sản phẩm
    private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("id"));
        productDAO.deleteProduct(id); // Gọi phương thức mới trong ProductDao
        response.sendRedirect(request.getContextPath() + "/product?action=list");
    }
}
