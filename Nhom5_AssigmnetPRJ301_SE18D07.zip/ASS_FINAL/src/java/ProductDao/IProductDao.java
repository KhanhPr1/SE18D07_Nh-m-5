
package ProductDao;

import java.sql.SQLException;
import Models.Product;
import java.util.List;


public interface IProductDao {
    void insertProduct(Product product) throws SQLException;
    Product selectProduct(int id);
    List<Product> selectAllProducts(boolean isAdmin);
    boolean updateProduct(Product product) throws SQLException;
    boolean deleteProduct(int id) throws SQLException;
    boolean updateProductStockAndStatus(int productId, int quantityPurchased) throws SQLException;
}
