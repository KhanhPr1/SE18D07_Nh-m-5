
package ProductDao;

import Dao.DBConnection;
import Models.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDao implements ICategoryDao{

    private static final String INSERT_CATEGORY_SQL = "INSERT INTO Categories (category_name, description) VALUES (?, ?)";
    private static final String SELECT_CATEGORY_BY_ID = "SELECT category_id, category_name, description, created_at, updated_at FROM Categories WHERE category_id = ?";
    private static final String SELECT_ALL_CATEGORIES = "SELECT category_id, category_name, description, created_at, updated_at FROM Categories";
    private static final String UPDATE_CATEGORY_SQL = "UPDATE Categories SET category_name = ?, description = ?, updated_at = GETDATE() WHERE category_id = ?";
    private static final String DELETE_CATEGORY_SQL = "DELETE FROM Categories WHERE category_id = ?";

    @Override
    public void insertCategory(Category category) throws SQLException {
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CATEGORY_SQL)) {
            preparedStatement.setString(1, category.getCategoryName());
            preparedStatement.setString(2, category.getDescription());
            preparedStatement.executeUpdate();
        }
    }

    @Override
    public Category selectCategory(int id) {
        Category category = null;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CATEGORY_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                String categoryName = rs.getString("category_name");
                String description = rs.getString("description");
                category = new Category(id, categoryName);
                category.setDescription(description);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return category;
    }

    @Override
    public List<Category> selectAllCategories() {
        List<Category> categories = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CATEGORIES)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("category_id");
                String categoryName = rs.getString("category_name");
                String description = rs.getString("description");
                Category category = new Category(id, categoryName);
                category.setDescription(description);
                categories.add(category);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }

    @Override
    public boolean updateCategory(Category category) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_CATEGORY_SQL)) {
            statement.setString(1, category.getCategoryName());
            statement.setString(2, category.getDescription());
            statement.setInt(3, category.getCategoryId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    @Override
    public boolean deleteCategory(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_CATEGORY_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }
}
