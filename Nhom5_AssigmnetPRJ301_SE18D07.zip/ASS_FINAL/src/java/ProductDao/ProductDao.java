package ProductDao;

import Dao.DBConnection;
import Models.Brand;
import Models.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Models.Product;
import Models.Role;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ProductDao implements IProductDao {

    // Cập nhật câu lệnh SQL với các trường mới theo định nghĩa bảng
    private static final String INSERT_PRODUCT_SQL = "INSERT INTO Products (product_name, description, price, stock, status, brand_id, category_id, image, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_PRODUCT_BY_ID = "SELECT p.*, b.brand_name, c.category_name FROM Products p "
            + "LEFT JOIN Brands b ON p.brand_id = b.brand_id "
            + "LEFT JOIN Categories c ON p.category_id = c.category_id "
            + "WHERE p.product_id = ?";

    private static final String SELECT_ALL_PRODUCTS = "SELECT p.*, b.brand_name, c.category_name FROM Products p "
            + "LEFT JOIN Brands b ON p.brand_id = b.brand_id "
            + "LEFT JOIN Categories c ON p.category_id = c.category_id";

    private static final String UPDATE_PRODUCT_SQL = "UPDATE Products SET product_name = ?, description = ?, price = ?, stock = ?, status = ?, brand_id = ?, category_id = ?, image = ?, updated_at = ? WHERE product_id = ?";

    private static final String DELETE_PRODUCT_SQL = "DELETE FROM Products WHERE product_id = ?";

    private static final String UPDATE_STOCK_SQL = "UPDATE Products "
            + "SET stock = stock - ?, "
            + "    status = CASE WHEN (stock - ?) = 0 THEN 'Unavailable' ELSE status END "
            + "WHERE product_id = ? AND stock >= ?";

    @Override
    public void insertProduct(Product product) throws SQLException {
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PRODUCT_SQL)) {
            preparedStatement.setString(1, product.getProductName());
            preparedStatement.setString(2, product.getDescription());
            preparedStatement.setBigDecimal(3, product.getPrice());
            preparedStatement.setInt(4, product.getStock());
            preparedStatement.setString(5, product.getStatus());
            preparedStatement.setInt(6, product.getBrand().getBrandId());
            preparedStatement.setInt(7, product.getCategory().getCategoryId());
            preparedStatement.setString(8, product.getImage());
            preparedStatement.setTimestamp(9, product.getCreatedAt());
            preparedStatement.setTimestamp(10, product.getUpdatedAt());
            preparedStatement.executeUpdate();
        }
    }

    @Override
    public Product selectProduct(int id) {
        Product product = null;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PRODUCT_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                String productName = rs.getString("product_name");
                String description = rs.getString("description");
                BigDecimal price = rs.getBigDecimal("price");
                int stock = rs.getInt("stock");
                String status = rs.getString("status");
                int brandId = rs.getInt("brand_id");
                String brandName = rs.getString("brand_name");
                int categoryId = rs.getInt("category_id");
                String categoryName = rs.getString("category_name");
                String image = rs.getString("image");
                Timestamp createdAt = rs.getTimestamp("created_at");
                Timestamp updatedAt = rs.getTimestamp("updated_at");

                Brand brand = new Brand(brandId, brandName);
                Category category = new Category(categoryId, categoryName);
                product = new Product(id, productName, description, price, stock, status, brand, category, image, createdAt, updatedAt);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }

    @Override
    public List<Product> selectAllProducts(boolean isAdmin) {
        List<Product> products = new ArrayList<>();

        String sql;
        if (isAdmin) {
            sql = "SELECT p.*, b.brand_name, c.category_name FROM Products p "
                    + "LEFT JOIN Brands b ON p.brand_id = b.brand_id "
                    + "LEFT JOIN Categories c ON p.category_id = c.category_id";
        } else {
            sql = "SELECT p.*, b.brand_name, c.category_name FROM Products p "
                    + "LEFT JOIN Brands b ON p.brand_id = b.brand_id "
                    + "LEFT JOIN Categories c ON p.category_id = c.category_id "
                    + "WHERE p.status <> 'Unavailable'";
        }
        try (Connection connection = DBConnection.getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                String description = rs.getString("description");
                BigDecimal price = rs.getBigDecimal("price");
                int stock = rs.getInt("stock");
                String status = rs.getString("status");

                int brandId = rs.getInt("brand_id");
                String brandName = rs.getString("brand_name");
                Brand brand = new Brand(brandId, brandName);

                int categoryId = rs.getInt("category_id");
                String categoryName = rs.getString("category_name");
                Category category = new Category(categoryId, categoryName);

                String image = rs.getString("image");
                Timestamp createdAt = rs.getTimestamp("created_at");
                Timestamp updatedAt = rs.getTimestamp("updated_at");

                products.add(new Product(productId, productName, description, price, stock, status, brand, category, image, createdAt, updatedAt));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public boolean updateProduct(Product product) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_PRODUCT_SQL)) {
            statement.setString(1, product.getProductName());
            statement.setString(2, product.getDescription());
            statement.setBigDecimal(3, product.getPrice());
            statement.setInt(4, product.getStock());
            statement.setString(5, product.getStatus());
            statement.setInt(6, product.getBrand().getBrandId());
            statement.setInt(7, product.getCategory().getCategoryId());
            statement.setString(8, product.getImage());
            statement.setTimestamp(9, product.getUpdatedAt());
            statement.setInt(10, product.getProductId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    @Override
    public boolean deleteProduct(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_PRODUCT_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public void updateProductStatus(int productId, String status) throws SQLException {
    String sql = "UPDATE Products SET status = ? WHERE product_id = ?";
    try (Connection connection = DBConnection.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        preparedStatement.setString(1, status);
        preparedStatement.setInt(2, productId);
        preparedStatement.executeUpdate();
    }
}
    
    public List<Product> searchProducts(String keyword) throws SQLException {
    List<Product> products = new ArrayList<>();
    String sql = "SELECT p.*, b.brand_name, c.category_name " +
                 "FROM Products p " +
                 "JOIN Brands b ON p.brand_id = b.brand_id " +
                 "JOIN Categories c ON p.category_id = c.category_id " +
                 "WHERE p.product_name LIKE ? OR p.description LIKE ?";

    try (Connection connection = DBConnection.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        preparedStatement.setString(1, "%" + keyword + "%");
        preparedStatement.setString(2, "%" + keyword + "%");

        ResultSet rs = preparedStatement.executeQuery();

        while (rs.next()) {
            int id = rs.getInt("product_id");
            String name = rs.getString("product_name");
            String description = rs.getString("description");
            BigDecimal price = rs.getBigDecimal("price");
            int stock = rs.getInt("stock");
            String status = rs.getString("status");
            String image = rs.getString("image");
            Timestamp createdAt = rs.getTimestamp("created_at");
            Timestamp updatedAt = rs.getTimestamp("updated_at");

            // Lấy thông tin thương hiệu
            int brandId = rs.getInt("brand_id");
            String brandName = rs.getString("brand_name");
            Brand brand = new Brand(brandId, brandName);

            // Lấy thông tin thể loại
            int categoryId = rs.getInt("category_id");
            String categoryName = rs.getString("category_name");
            Category category = new Category(categoryId, categoryName);

            // Thêm sản phẩm vào danh sách
            products.add(new Product(id, name, description, price, stock, status, brand, category, image, createdAt, updatedAt));
        }
    }
    return products;
}




    @Override
    public boolean updateProductStockAndStatus(int productId, int quantityPurchased) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_STOCK_SQL)) {
            statement.setInt(1, quantityPurchased);
            statement.setInt(2, quantityPurchased);
            statement.setInt(3, productId);
            statement.setInt(4, quantityPurchased);
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

}
