package ControllerOrder;

import Models.CartItem;
import Models.Order;
import Models.OrderDetail;
import Models.User;
import OrderDAO.OrderDAO;
import ProductDao.ProductDao;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import uitl.EmailService;
import uitl.IJavaMail;

@WebServlet(name = "CheckOutServlet", urlPatterns = {"/checkout"})
public class CheckOutServlet extends HttpServlet {

    private OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart?action=view");
            return;
        }

        // Kiểm tra tồn kho từng sản phẩm trong giỏ hàng
        for (CartItem item : cart) {
            int requestedQty = item.getQuantity();
            int stockQty = item.getProduct().getStock();
            if (requestedQty > stockQty) {
                request.setAttribute("errorMessage", "Sản phẩm " + item.getProduct().getProductName()
                        + " chỉ còn " + stockQty + " sản phẩm trong kho. Vui lòng điều chỉnh số lượng.");
                request.getRequestDispatcher("Cart/Cart.jsp").forward(request, response);
                return;
            }
        }

        User currentUser = (User) session.getAttribute("user");
        int userId = currentUser.getUserId();
        BigDecimal totalPrice = BigDecimal.ZERO; // Dùng BigDecimal thay vì double
        List<OrderDetail> details = new ArrayList<>();

        for (CartItem item : cart) {
            BigDecimal itemTotal = item.getProduct().getPrice().multiply(BigDecimal.valueOf(item.getQuantity())); // price * quantity
            totalPrice = totalPrice.add(itemTotal); // Cộng dồn vào tổng giá trị đơn hàng

            OrderDetail detail = new OrderDetail();
            detail.setProduct(item.getProduct());
            detail.setQuantity(item.getQuantity());
            detail.setPrice(item.getProduct().getPrice());
            details.add(detail);
        }

        // Áp dụng khuyến mãi 10%
        totalPrice = totalPrice.multiply(BigDecimal.valueOf(0.9));

        Order order = new Order();
        order.setUserId(userId);
        order.setTotalPrice(totalPrice); // Chỉnh thành BigDecimal
        order.setStatus("Done");
        order.setOrderDetails(details);

        try {
            int orderId;
            try {
                orderId = orderDAO.insertOrder(order);
                System.out.println("Order created with ID: " + orderId);
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("errorMessage", "Lỗi khi tạo đơn hàng: " + e.getMessage());
                request.getRequestDispatcher("Cart/Cart.jsp").forward(request, response);
                return;
            }

            order.setId(orderId);
            orderDAO.insertOrderDetail(order);

            // Cập nhật tồn kho và trạng thái cho từng sản phẩm
            ProductDao productDao = new ProductDao();
            for (CartItem item : cart) {
                int productId = item.getProduct().getProductId();
                int quantityPurchased = item.getQuantity();
                boolean updated = productDao.updateProductStockAndStatus(productId, quantityPurchased);
                if (!updated) {
                    System.out.println("Không thể cập nhật stock cho sản phẩm ID: " + productId);
                }
            }

            // Xóa giỏ hàng sau khi thanh toán thành công
            session.removeAttribute("cart");

            // Gửi email xác nhận
            if (currentUser != null) {
                String subject = "Order Confirmation - Order #" + orderId;
                String orderLink="http://localhost:9999/ASS_FINAL/order-list";
                String message = "<html>\n"
                        + "  <head>\n"
                        + "    <meta charset='UTF-8'>\n"
                        + "  </head>\n"
                        + "  <body style='font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 0; padding: 0;'>\n"
                        + "    <div style='max-width: 600px; margin: 30px auto; background-color: #ffffff; padding: 25px; "
                        + "      border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); border: 1px solid #e0e0e0;'>\n"
                        + "      <div style='background-color: #007bff; color: #ffffff; padding: 15px; text-align: center; "
                        + "        font-size: 22px; font-weight: bold; border-radius: 8px 8px 0 0;'>\n"
                        + "        Shop Do Choi\n"
                        + "      </div>\n"
                        + "      <div style='margin: 20px 0; font-size: 16px; color: #333; line-height: 1.6;'>\n"
                        + "        <p>Dear <strong>" + currentUser.getUsername() + "</strong>,</p>\n"
                        + "        <p>Thank you for your order. Your order ID is <strong>" + orderId + "</strong>.</p>\n"
                        + "        <p>Total price (after discount): <strong>$" + totalPrice + "</strong></p>\n"
                        + "        <p>We will notify you when your order is shipped.</p>\n"
                        + "        <p style='text-align: center;'>\n"
                        + "          <a href='" + orderLink + "' style='display: inline-block; background-color: #28a745; color: #ffffff; "
                        + "            padding: 12px 24px; text-decoration: none; border-radius: 5px; font-size: 16px; font-weight: bold; "
                        + "            transition: background-color 0.3s ease-in-out;'>\n"
                        + "            View Order\n"
                        + "          </a>\n"
                        + "        </p>\n"
                        + "      </div>\n"
                        + "      <div style='font-size: 14px; color: #555; text-align: center; margin-top: 25px; padding-top: 15px; "
                        + "        border-top: 1px solid #dddddd;'>\n"
                        + "        <p>Best regards,</p>\n"
                        + "        <p><strong>Shop Do Choi Team</strong></p>\n"
                        + "      </div>\n"
                        + "    </div>\n"
                        + "  </body>\n"
                        + "</html>";

                IJavaMail emailService = new EmailService();
                emailService.send(currentUser.getEmail(), subject, message);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect(request.getContextPath() + "/Cart/OrderSuccess.jsp");
    }
}
