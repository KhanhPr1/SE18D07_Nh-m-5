
package ControllerOrder;

import Models.CartItem;
import Models.Product;
import ProductDao.ProductDao;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;



@WebServlet(name = "CartServlet", urlPatterns = {"/cart"})
public class CartServlet extends HttpServlet {

    private List<CartItem> getCart(HttpServletRequest request) {
        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null) {
            cart = new ArrayList<>();
            session.setAttribute("cart", cart);
        }
        return cart;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "view":
                    viewCart(request, response);
                    break;
                case "delete":
                    deleteCartItem(request, response);
                    break;
                default:
                    viewCart(request, response);
                    break;
            }
        } catch (Exception e) {

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "add":
                    addToCart(request, response);
                    break;
                case "update":
                    updateCart(request, response);
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/cart?action=view");
                    break;
            }
        } catch (Exception e) {

        }
    }

    private void addToCart(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Lấy đối tượng Product từ cơ sở dữ liệu bằng cách sử dụng ProductDao
        ProductDao productDao = new ProductDao(); 
        Product product = null;
        try {
            product = productDao.selectProduct(productId);
        } catch (Exception e) {
            e.printStackTrace();
            // Xử lý lỗi nếu không lấy được sản phẩm, có thể chuyển hướng đến trang lỗi
            response.sendRedirect(request.getContextPath() + "/error.jsp");
            return;
        }

        // Nếu sản phẩm không tồn tại, chuyển hướng đến trang thông báo lỗi
        if (product == null) {
            response.sendRedirect(request.getContextPath() + "/error.jsp");
            return;
        }

        // Lấy giỏ hàng từ session
        List<CartItem> cart = getCart(request);
        boolean found = false;
        for (CartItem item : cart) {
            if (item.getProduct().getProductId() == productId) {
                item.setQuantity(item.getQuantity() + quantity);
                found = true;
                break;
            }
        }
        if (!found) {
            cart.add(new CartItem(product, quantity));
        }
        response.sendRedirect(request.getContextPath() + "/cart?action=view");
    }

    private void updateCart(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        List<CartItem> cart = getCart(request);
        for (CartItem item : cart) {
            int qty = Integer.parseInt(request.getParameter("quantity_" + item.getProduct().getProductId()));
            item.setQuantity(qty);
        }
        response.sendRedirect(request.getContextPath() + "/cart?action=view");
    }

    private void deleteCartItem(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        List<CartItem> cart = getCart(request);
        cart.removeIf(item -> item.getProduct().getProductId() == productId);
        response.sendRedirect(request.getContextPath() + "/cart?action=view");
    }

    private void viewCart(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Cart/Cart.jsp");
        dispatcher.forward(request, response);
    }
}
