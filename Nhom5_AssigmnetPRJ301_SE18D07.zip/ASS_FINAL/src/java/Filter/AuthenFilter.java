package Filter;

import Models.Role;
import Models.User;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter(filterName = "AuthenFilter", urlPatterns = {"/*"})
public class AuthenFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String uri = req.getRequestURI();

        // Loại trừ các trang/tài nguyên không cần kiểm tra
        // - endsWith("login.jsp") để bỏ qua trang login
        // - endsWith("403.jsp") để tránh vòng lặp khi redirect 403
        // - endsWith(".css"), endsWith(".js"), v.v. nếu bạn có file tĩnh
        // Lấy tham số action từ request
        String actionParam = req.getParameter("action");
        if (uri.endsWith("login.jsp")
                || uri.endsWith("/login")
                || uri.endsWith("/register.jsp")
                || uri.endsWith("/register")
                || uri.endsWith("/logout")
                || uri.endsWith("403.jsp")
                || uri.contains("/css/")
                || uri.contains("/js/")
                || uri.contains("/img/")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        System.out.println("Requested URI: " + uri);
        System.out.println("Session exists: " + (session != null));
        System.out.println("User in session: " + (session != null ? session.getAttribute("user") : "null"));

        if (session == null || session.getAttribute("user") == null) {
            if (uri.contains("/home") || uri.endsWith("home.jsp") || uri.equals(req.getContextPath() + "/")) {
                // Cho phép vào home không cần đăng nhập
                chain.doFilter(request, response);
                return;
            } else {
                res.sendRedirect(req.getContextPath() + "/authenticator_authorization/login.jsp");
                return;
            }
        }

        // Đã đăng nhập => Lấy role
        User a = (User) session.getAttribute("user");
        Role role = a.getRole();

        // Kiểm tra quyền
        if (role.getRoleId() == 1) {
            // Admin => được phép tất cả (list, create, update, delete)
            chain.doFilter(request, response);
        } else if (role.getRoleId() == 2) {
            // Manager => được crud với product
            if (uri.contains("/checkout") || uri.contains("/cart")
                    || uri.contains("/home") || uri.endsWith("navAdmin.jsp")
                    || uri.contains("/profile") || uri.endsWith("home.jsp")
                    || uri.contains("/product")) {
                chain.doFilter(request, response);
            } else {
                // Không có quyền => chuyển hướng 403 hoặc trang báo lỗi
                res.sendRedirect(req.getContextPath() + "/authenticator_authorization/login.jsp");
            }
        } else {
            if (uri.contains("/checkout") || uri.contains("/cart")
                    || uri.contains("/home") || uri.endsWith("navAdmin.jsp")
                    || uri.contains("/profile") || uri.endsWith("home.jsp")) {
                chain.doFilter(request, response);
            } else {
                // Không có quyền => chuyển hướng 403 hoặc trang báo lỗi
                res.sendRedirect(req.getContextPath() + "/authenticator_authorization/login.jsp");
            }
        }
    }

}
