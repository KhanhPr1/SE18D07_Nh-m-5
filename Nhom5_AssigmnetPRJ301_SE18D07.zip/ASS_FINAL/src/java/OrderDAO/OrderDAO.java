package OrderDAO;

import Dao.DBConnection;
import Models.Order;
import Models.OrderDetail;
import Models.Product;
import java.math.BigDecimal;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Timestamp;
import java.util.Date;

public class OrderDAO implements IOrderDAO {
    private static final String INSERT_ORDER_SQL = 
        "INSERT INTO Orders (user_id, order_date, total_price, status) VALUES (?, ?, ?, ?)";
    
    private static final String INSERT_ORDER_DETAIL_SQL = 
        "INSERT INTO OrderDetails (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";

    @Override
    public int insertOrder(Order order) throws SQLException {
        int generatedId = 0;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_ORDER_SQL, Statement.RETURN_GENERATED_KEYS)) {
            order.setOrderDate(new Timestamp(System.currentTimeMillis()));

            ps.setInt(1, order.getUserId());
            ps.setTimestamp(2, new java.sql.Timestamp(order.getOrderDate().getTime())); // Đặt order_date
            ps.setBigDecimal(3, order.getTotalPrice()); // Dùng BigDecimal cho giá trị tổng
            ps.setString(4, order.getStatus());
            ps.executeUpdate();
            
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    generatedId = rs.getInt(1);
                }
            }
        }
        return generatedId;
    }

    @Override
    public void insertOrderDetail(Order order) throws SQLException {
        List<OrderDetail> details = order.getOrderDetails();
        if (details == null || details.isEmpty()) return; // Kiểm tra danh sách không rỗng

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_ORDER_DETAIL_SQL)) {
            
            for (OrderDetail detail : details) {
                ps.setInt(1, order.getId()); // Đảm bảo orderId đã được thiết lập
                ps.setInt(2, detail.getProduct().getProductId());
                ps.setInt(3, detail.getQuantity());
                ps.setBigDecimal(4, detail.getPrice()); // Dùng BigDecimal thay vì double
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    // Lấy danh sách đơn hàng theo User ID
    public List<Order> getOrdersByUserId(int userId) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM Orders WHERE user_id = ? ORDER BY order_date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Order order = new Order();
                    order.setId(rs.getInt("id"));
                    order.setUserId(rs.getInt("user_id"));
                    order.setTotalPrice(rs.getBigDecimal("total_price")); // Lấy BigDecimal
                    order.setStatus(rs.getString("status"));
                    order.setOrderDate(rs.getTimestamp("order_date")); // Lấy kiểu Timestamp

                    order.setOrderDetails(getOrderDetails(order.getId()));

                    orders.add(order);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orders;
    }

    // Lấy chi tiết đơn hàng theo Order ID
    private List<OrderDetail> getOrderDetails(int orderId) {
        List<OrderDetail> details = new ArrayList<>();
        String sql = """
            SELECT od.*, p.product_name, p.price 
            FROM OrderDetails od 
            JOIN Products p ON od.product_id = p.product_id 
            WHERE od.order_id = ?
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    OrderDetail detail = new OrderDetail();
                    detail.setQuantity(rs.getInt("quantity"));
                    detail.setPrice(rs.getBigDecimal("price")); // Sử dụng BigDecimal

                    Product product = new Product();
                    product.setProductId(rs.getInt("product_id"));
                    product.setProductName(rs.getString("product_name"));

                    detail.setProduct(product);
                    details.add(detail);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }
}
