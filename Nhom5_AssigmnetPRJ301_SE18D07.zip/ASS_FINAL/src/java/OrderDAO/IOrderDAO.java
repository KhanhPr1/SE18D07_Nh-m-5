
package OrderDAO;

import Models.Order;
import java.sql.SQLException;


public interface IOrderDAO {
    int insertOrder(Order order) throws SQLException;
    void insertOrderDetail(Order order) throws SQLException;
}
